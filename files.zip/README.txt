Put your two personal files here:
  profile.jpg   — your photo (any name is fine as long as you update
                  the "photo" path in data.js to match)
  resume.pdf    — your résumé (same note — update "resumeUrl" in
                  data.js if you rename it)

The site works fine before you add these: it falls back to an
initials avatar, and the résumé button simply won't appear if you set
resumeUrl to null in data.js.
