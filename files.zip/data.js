/**
 * ============================================================
 *  SITE CONTENT — this is the only file you need to edit for
 *  routine updates. index.html, styles.css and app.js handle
 *  layout and behaviour and shouldn't need to change when you
 *  just want to add a project or fix a bio line.
 *
 *  To add a new project: copy an object inside an "items" array
 *  and change its fields.
 *  To add a new category: copy one of the objects in
 *  "categories" (including its own "items" array) and give it a
 *  new "id".
 * ============================================================
 */

const SITE_DATA = {
  profile: {
    name: "Jane Doe",
    title: "Computer scientist and data scientist working on AI safety",
    bio:
      "I build tools and run experiments at the boundary of machine " +
      "learning and software systems, with a focus on making AI systems " +
      "safer and more trustworthy. My work spans alignment research, " +
      "applied data science and general software engineering — the " +
      "categories below are organised around that mix.",

    // Path to a photo, relative to index.html. Set to null (no quotes)
    // to show a plain initials avatar instead — the page works fine
    // either way, so there's no rush to add a photo.
    photo: "assets/profile.jpg",

    // Path to your résumé PDF, relative to index.html.
    resumeUrl: "assets/resume.pdf",

    contacts: [
      { label: "Email", url: "mailto:jane@example.com" },
      { label: "GitHub", url: "https://github.com/janedoe" },
      { label: "Google Scholar", url: "https://scholar.google.com/citations?user=XXXXXXX" },
      { label: "LinkedIn", url: "https://www.linkedin.com/in/janedoe" }
    ]
  },

  // Each object below becomes one card on the board. The order here
  // is only the *default* order — once a visitor drags a card, their
  // browser remembers the new order for their next visit.
  categories: [
    {
      id: "ai-safety",
      title: "AI Safety",
      accent: "#4B3F72",
      description: "Alignment, evaluation and interpretability work.",
      items: [
        {
          title: "Detecting reward hacking in RLHF",
          url: "https://github.com/janedoe/reward-hacking-eval",
          description: "Benchmark and short paper on evaluation gaming in RLHF pipelines."
        },
        {
          title: "Interpreting sparse autoencoders",
          url: "https://github.com/janedoe/sae-interpretability",
          description: "A small toolkit for feature analysis in open-weight language models."
        }
      ]
    },
    {
      id: "computer-science",
      title: "Computer Science",
      accent: "#1F6F78",
      description: "Systems, algorithms and software projects.",
      items: [
        {
          title: "A minimal Raft-based job scheduler",
          url: "https://github.com/janedoe/mini-scheduler",
          description: "Distributed task queue built for a graduate systems course."
        },
        {
          title: "Compiler for a toy stack language",
          url: "https://github.com/janedoe/stackc",
          description: "Lexer, parser and bytecode VM written from scratch in Rust."
        }
      ]
    },
    {
      id: "data-science",
      title: "Data Science",
      accent: "#B8752E",
      description: "Analysis, modelling and data visualisation.",
      items: [
        {
          title: "Climate migration dataset analysis",
          url: "https://github.com/janedoe/climate-migration",
          description: "Notebook and write-up on internal migration trends, 2000–2023."
        },
        {
          title: "Forecasting model for retail demand",
          url: "https://github.com/janedoe/demand-forecasting",
          description: "Gradient-boosted forecasting pipeline with a short case study."
        }
      ]
    },
    {
      id: "other",
      title: "Other Projects",
      accent: "#5B6470",
      description: "Everything that doesn't fit neatly above.",
      items: [
        {
          title: "Personal blog",
          url: "https://janedoe.dev/blog",
          description: "Occasional writing on research, tools and the odd side project."
        }
      ]
    }
  ]
};
